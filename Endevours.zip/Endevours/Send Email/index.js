// function sendEmail() {
// 	Email.send({
// 	Host: "smtp.gmail.com",
// 	Username : "fusionprojectwork@gmail.com",
// 	Password : "HLM@123456",
// 	To : 'mehulraj1995@gmail.com',
// 	From : "fusionprojectwork@gmail.com",
// 	Subject : "Send Email property for the app",
// 	Body : "This mail is regarding the send email property for the Fusion App",
// 	}).then(
// 		message => alert("mail sent successfully")
// 	);
// }

function sendMail() {
    var tempParams = {
        from_name: document.getElementsById("fromName").value,
        to_name: document.getElementsById("toName").value,
        message: document.getElementsById("msg").value
    }

    emailjs.send("service_1s3ru7v", "template_b6lpvcx", tempParams)
    .then(function(res){
        console.log("success", res.status);
    })
}