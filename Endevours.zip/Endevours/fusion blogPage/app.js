const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const app = express();
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json());



mongoose.connect('mongodb+srv://John:Welcome@123@cluster0.jsl2e.mongodb.net/Incubation?retryWrites=true&w=majority', {
    useUnifiedTopology: true,
    useNewUrlParser: true
}, (err) => {
    if (!err) {
        console.log("Mongodb connected");
    } else {
        console.log("Mongodb is not connected");
    }
});

const BlogPage_Schema = new mongoose.Schema({
    blogGroupName: String,
    blogTitle: String,
    blogContent: String
})
const BlogDetail = mongoose.model("BlogDetail", BlogPage_Schema);


app.route("/compose")
    .post((req, res) => {
        const blogPost = new BlogDetail({
            blogGroupName: req.body.blogGroupName,
            blogTitle: req.body.blogTitle,
            blogContent: req.body.blogContent
        })
        blogPost.save();
        return res.status(200).json(blogPost);
    })

app.route("/posts/:blogGroupName")
    .get((req, res) => {
        const givenBlogGroupName = req.params.blogGroupName;
        BlogDetail.find({
            blogGroupName: givenBlogGroupName
        }, function (err, foundList) {
            if (err) {
                console.log(err);
            } else {
                console.log(foundList);
            }
        })
    })

app.route("/posts/:postId")
    .get((req, res) => {
        const requestedId = req.params.postId;
        BlogDetail.findOne({
            _id: requestedId
        }, function (err, blogPost) {
            if (err) {
                console.log(err);
            } else {
                console.log(blogPost);
            }
        })
    })


app.listen(8080, () => console.log("Server started at http://localhost:8080"));